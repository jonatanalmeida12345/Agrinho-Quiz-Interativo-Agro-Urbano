let items = [];
let selected = null;
function setup() {
  createCanvas(600, 400);
  items = [
    {pos: createVector(100,100), type:"campo"},
    {pos: createVector(100,300), type:"campo"},
    {pos: createVector(500,100), type:"cidade"},
    {pos: createVector(500,300), type:"cidade"},
  ];
}

function draw() {
  background(255);
  textSize(16); textAlign(CENTER, CENTER);
  for (let it of items) {
    fill(it.type=="campo"? 'green':'blue');
    ellipse(it.pos.x, it.pos.y, 40);
  }
  if (selected && mouseIsPressed) {
    stroke(0); line(selected.pos.x, selected.pos.y, mouseX, mouseY);
  }
}

function mousePressed() {
  for (let it of items) {
    if (dist(mouseX, mouseY, it.pos.x, it.pos.y) < 20) {
      selected = it;
    }
  }
}

function mouseReleased() {
  if (selected) {
    for (let it of items) {
      if (it !== selected && dist(mouseX, mouseY, it.pos.x, it.pos.y) < 20) {
        if (it.type !== selected.type) {
          console.log("Conexão correta!");
        } else {
          console.log("Conexão errada!");
        }
      }
    }
    selected = null;
  }
}